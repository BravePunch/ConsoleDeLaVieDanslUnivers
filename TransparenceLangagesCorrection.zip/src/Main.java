
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("[Lecture d'un fichier xml]\n");
		
		Etoile e1 = new Etoile("GeanteBleue");
		
		System.out.println(e1.toString());
		
		System.out.println("-----------------------------------------------\n\n");
		
		Etoile e2 = new Etoile("GeanteRouge");
		
		System.out.println(e2.toString());
		
		System.out.println("-----------------------------------------------\n\n");
		
		Planete p1 = new Planete("Terre");
		
		System.out.println(p1.toString());
		
		System.out.println("-----------------------------------------------\n\n");
		
		System.out.println("[FIN]");
	}

}
